
// exports.sampleRequest=function(req,res){
//     let name="get all product"
//     let response={
//         "products":name
//     }
//     res.statusCode=200;
//     res.setHeader('Content-Type', 'application/json');
//     res.end(JSON.stringify(response))
// }

// exports.testRequest=function(req,res){
//     body="products added successfully"
//     let response={"products":body}
//     res.statusCode=200;
//     res.setHeader('content-type','application/json');
//     res.end(JSON.stringify(response))
// }