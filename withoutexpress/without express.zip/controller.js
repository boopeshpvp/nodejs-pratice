// const http=require('http')
// const url=require('url')

// module.exports=http.createServer((req,res)=>{
//     let service=require('./service.js')
//     const reqUrl=url.parse(req.url,true)

//     if(reqUrl.pathname=="/sample" && req.method==="GET"){
  
//         service.sampleRequest(req,res)
//     }
// })