const fs = require("fs");

const data = ["add.txt", "subtract.txt", "multiply.txt", "divide.txt"];
let count = 0;

const result = setInterval(() => {
  if (count === data.length) {
    clearInterval(result);
  } else {
    fs.createReadStream(`./src/origin/${data[count]}`).pipe(
      fs.createWriteStream(`./src/destination/${data[count]}`)
    );
    const info = {
      name: data[count],
      time: new Date(),
    };

    fs.appendFile(
      "./src/log/index.js",
      JSON.stringify(info),
      function (err, data) {
        console.log(data);
      }
    );
    count = count + 1;
  }
}, 3000);
